from typing import List
from starlette.config import Config
from starlette.datastructures import CommaSeparatedStrings, Secret
import os

###
# Properties configurations
###

# API_PREFIX = "/api"
# JWT_TOKEN_PREFIX = "Authorization
# config = Config(".env")
# ROUTE_PREFIX_V1 = "/v1"
# ALLOWED_HOSTS: List[str] = config(
#     "ALLOWED_HOSTS",
#     cast=CommaSeparatedStrings,
#     default="",
# )

POSTGRES_USER="postgres"
POSTGRES_PASSWORD="root"
POSTGRES_SERVER= "localhost"
POSTGRES_PORT = 5432
POSTGRES_DB = "postgres"


SQLALCHEMY_DATABASE_URL = f"postgresql://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_SERVER}:{POSTGRES_PORT}/{POSTGRES_DB}"


class Config:
    ENV: str = "development"
    DEBUG: bool = True
    APP_HOST: str = SQLALCHEMY_DATABASE_URL
    APP_PORT: int = POSTGRES_PORT
    # WRITER_DB_URL: str = os.environ.get('RDS_PROXY_WRITER_ENDPOINT')
    # READER_DB_URL: str = os.environ.get('RDS_PROXY_READER_ENDPOINT')

    # AWS_SECRET_KEY: str = "fastapi"
    # AWS_ACCESS_KEY: str = "HS256"
    RDS_PROXY_USERNAME: str = POSTGRES_USER
    RDS_DATABASE: str = POSTGRES_DB
    # RDS_PROXY_SSL_CERTIFICATE_NAME: str = os.environ.get('RDS_PROXY_SSL_CERTIFICATE_NAME')


class DevelopmentConfig(Config):
    # WRITER_DB_URL: str = os.environ.get('RDS_PROXY_WRITER_ENDPOINT')
    # READER_DB_URL: str = os.environ.get('RDS_PROXY_READER_ENDPOINT')
    pass

def get_config():
    env = os.getenv("ENV", "dev")
    config_type = {
        "dev": DevelopmentConfig(),
    }
    return config_type[env]


config: Config = get_config()
